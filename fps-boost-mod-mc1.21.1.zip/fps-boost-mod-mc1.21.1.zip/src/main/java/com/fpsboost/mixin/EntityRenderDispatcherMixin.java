package com.fpsboost.mixin;

import com.fpsboost.config.FpsBoostConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {

    /**
     * Não renderiza entidades além de entityRenderDistance blocos da câmera.
     * O vanilla renderiza qualquer entidade dentro da frustum até o limite de
     * chunks; esse corte antecipado poupa CPU (IA de renderização) e GPU.
     * Jogadores nunca são removidos, para não atrapalhar o multiplayer.
     */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <T extends Entity> void fpsboost$cullDistantEntities(T entity, Frustum frustum,
                                                                 double x, double y, double z,
                                                                 CallbackInfoReturnable<Boolean> cir) {
        if (entity == null || entity instanceof PlayerEntity) {
            return;
        }
        FpsBoostConfig config = FpsBoostConfig.get();
        if (config == null || !config.enabled) {
            return;
        }
        Vec3d camera = MinecraftClient.getInstance().gameRenderer.getCamera().getPos();
        double maxDistanceSq = config.entityRenderDistance * config.entityRenderDistance;
        if (entity.squaredDistanceTo(camera.x, camera.y, camera.z) > maxDistanceSq) {
            cir.setReturnValue(false);
        }
    }
}
