package com.fpsboost.mixin;

import com.fpsboost.config.FpsBoostConfig;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityRenderDispatcherMixin {

    /**
     * Não renderiza block entities (baús, armazéns, placas, camas, etc.) além de
     * blockEntityRenderDistance blocos. Esses renderizadores costumam ser pesados
     * (especialmente com muitos baús em farms), então o ganho de FPS é real.
     */
    @Inject(
        method = "render(Lnet/minecraft/block/entity/BlockEntity;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void fpsboost$cullDistantBlockEntities(BlockEntity blockEntity, float tickDelta,
                                                   MatrixStack matrices, VertexConsumerProvider vcp,
                                                   CallbackInfo ci) {
        if (blockEntity == null) {
            return;
        }
        FpsBoostConfig config = FpsBoostConfig.get();
        if (config == null || !config.enabled) {
            return;
        }
        Vec3d camera = MinecraftClient.getInstance().gameRenderer.getCamera().getPos();
        double maxDistanceSq = config.blockEntityRenderDistance * config.blockEntityRenderDistance;
        if (blockEntity.getPos().getSquaredDistance(camera) > maxDistanceSq) {
            ci.cancel();
        }
    }
}
