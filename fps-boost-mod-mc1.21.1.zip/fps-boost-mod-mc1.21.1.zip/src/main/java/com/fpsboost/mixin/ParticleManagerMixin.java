package com.fpsboost.mixin;

import com.fpsboost.config.FpsBoostConfig;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEffect;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {

    /**
     * Limita a quantidade de partículas: cada partícula nova só é criada com
     * probabilidade igual a particleMultiplier. Menos partículas = menos chamadas
     * de renderização e menos carga na GPU/CPU.
     *
     * Se este mixin falhar ao aplicar (mudança de assinatura no Yarn), troque a
     * assinatura para terminar em "...DDDDDD)V" (sem retorno).
     */
    @Inject(
        method = "addParticle(Lnet/minecraft/client/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
        at = @At("HEAD"),
        cancellable = true
    )
    private void fpsboost$limitParticles(ParticleEffect effect, double x, double y, double z,
                                         double vx, double vy, double vz,
                                         CallbackInfoReturnable<Particle> cir) {
        FpsBoostConfig config = FpsBoostConfig.get();
        if (config != null && config.enabled && config.particleMultiplier < 1.0
                && Math.random() >= config.particleMultiplier) {
            cir.setReturnValue(null);
        }
    }
}
