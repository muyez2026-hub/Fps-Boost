package com.fpsboost.mixin;

import com.fpsboost.config.FpsBoostConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public abstract class ItemEntityRendererMixin {

    /**
     * Não renderiza itens dropados além de itemEntityRenderDistance blocos.
     * Muitos itens no chão (farms, moedas em servidores) geram draw calls
     * individuais — cortá-los à distância alivia bastante a GPU.
     */
    @Inject(
        method = "render(Lnet/minecraft/entity/ItemEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void fpsboost$cullDistantItems(ItemEntity entity, float yaw, float tickDelta,
                                           MatrixStack matrices, VertexConsumerProvider vcp,
                                           CallbackInfo ci) {
        if (entity == null) {
            return;
        }
        FpsBoostConfig config = FpsBoostConfig.get();
        if (config == null || !config.enabled) {
            return;
        }
        Vec3d camera = MinecraftClient.getInstance().gameRenderer.getCamera().getPos();
        double maxDistanceSq = config.itemEntityRenderDistance * config.itemEntityRenderDistance;
        if (entity.squaredDistanceTo(camera.x, camera.y, camera.z) > maxDistanceSq) {
            ci.cancel();
        }
    }
}
