package com.fpsboost;

import com.fpsboost.config.FpsBoostConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

public class FpsBoostClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        FpsBoostConfig.load();

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            if (FpsBoostConfig.get().applyVideoOptimizations) {
                applyVideoOptimizations(client);
            }
        });
    }

    /**
     * Aplica uma vez as opções gráficas do vanilla que mais aliviam GPU/CPU.
     * (Partículas em MINIMAL, nuvens desligadas, sombras de entidades desligadas,
     * e "Entity Distance" reduzido). Edite config/fpsboost.json para desativar.
     */
    private static void applyVideoOptimizations(MinecraftClient client) {
        GameOptions options = client.options;
        options.particlesMode = ParticlesMode.MINIMAL;
        options.cloudRenderMode = CloudRenderMode.OFF;
        options.entityShadows = false;
        if (options.entityDistanceScaling > 0.75) {
            options.entityDistanceScaling = 0.75;
        }
        options.save();
    }
}
