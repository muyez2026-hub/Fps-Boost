package com.fpsboost.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class FpsBoostConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("fpsboost.json");
    private static FpsBoostConfig instance;

    /** Liga/desliga todas as otimizações por mixin. */
    public boolean enabled = true;

    /** Distância máxima (em blocos) para renderizar entidades. */
    public double entityRenderDistance = 48.0;

    /** Distância máxima (em blocos) para renderizar block entities (baús, placas, etc.). */
    public double blockEntityRenderDistance = 32.0;

    /** Distância máxima (em blocos) para renderizar itens dropados no chão. */
    public double itemEntityRenderDistance = 24.0;

    /** Fração de partículas exibidas (0.0 = nenhuma, 1.0 = comportamento vanilla). */
    public double particleMultiplier = 0.4;

    /** Aplica as otimizações gráficas do vanilla (nuvens, sombras, partículas) ao iniciar. */
    public boolean applyVideoOptimizations = true;

    public static FpsBoostConfig get() {
        return instance;
    }

    public static void load() {
        if (Files.exists(PATH)) {
            try (Reader reader = Files.newBufferedReader(PATH)) {
                instance = GSON.fromJson(reader, FpsBoostConfig.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (instance == null) {
            instance = new FpsBoostConfig();
        }
        save();
    }

    public static void save() {
        try (Writer writer = Files.newBufferedWriter(PATH)) {
            GSON.toJson(instance, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
